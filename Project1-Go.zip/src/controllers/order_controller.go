package controllers

import (
	"fmt"
	"net/http"
	"project-1/src/models"
	"project-1/src/services"

	"github.com/gin-gonic/gin"
)

func Checkout(c *gin.Context) {
	var order models.Order
	if err := c.ShouldBindJSON(&order); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	if len(order.Items) == 0 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Tidak ada item dalam pesanan"})
		return
	}

	// ── Ambil userID dari context dan set ke order ──
	uidAny, exists := c.Get("userID")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User tidak terautentikasi"})
		return
	}
	userID, ok := uidAny.(uint)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Format userID tidak valid"})
		return
	}
	order.UserID = userID

	// ── Hitung total & reset IDs pada Items ──
	var total float64
	for i := range order.Items {
		total += order.Items[i].Price * float64(order.Items[i].Quantity)
		order.Items[i].ID = 0      // prevent ID collision
		order.Items[i].OrderID = 0 // akan di-set oleh GORM
	}
	order.Total = total
	order.Status = "pending"

	fmt.Printf("RECEIVED ORDER: %+v\n", order)

	// ── Simpan ke DB ──
	if err := services.CreateOrder(&order); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// ── Kembalikan detail order yang baru dibuat ──
	c.JSON(http.StatusCreated, order)
}

// UpdateOrderStatusHandler untuk admin mengubah status pesanan
func UpdateOrderStatusHandler(c *gin.Context) {
	// parse ID
	var id uint
	if _, err := fmt.Sscan(c.Param("id"), &id); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "ID tidak valid"})
		return
	}

	// parse body { status: "berhasil" }
	var req struct {
		Status string `json:"status"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// update
	if err := services.UpdateOrderStatus(id, req.Status); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Gagal update status"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Status diperbarui"})
}

// TERBARU
// GetAllOrdersHandler untuk endpoint admin melihat semua order
// src/controllers/order_controller.go

func GetAllOrdersHandler(c *gin.Context) {
	// parse query params (format YYYY-MM-DD)
	start := c.Query("startDate")
	end := c.Query("endDate")

	var (
		orders []models.Order
		err    error
	)
	if start != "" && end != "" {
		// ambil dengan filter tanggal
		orders, err = services.GetOrdersByDate(start, end)
	} else {
		// ambil semua tanpa filter
		orders, err = services.GetAllOrders()
	}

	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Gagal ambil pesanan"})
		return
	}
	c.JSON(http.StatusOK, orders)
}

// GetOrderByIDHandler untuk endpoint user melihat order by ID
func GetOrderByIDHandler(c *gin.Context) {
	idParam := c.Param("id")
	var id uint
	if _, err := fmt.Sscan(idParam, &id); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "ID tidak valid"})
		return
	}

	order, err := services.GetOrderByID(id)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Order tidak ditemukan"})
		return
	}
	c.JSON(http.StatusOK, order)
}

// GetOrdersByUserIDHandler untuk endpoint user melihat riwayat pesanan sendiri
func GetOrdersByUserIDHandler(c *gin.Context) {
	// Ambil userID dari context (middleware AuthUserMiddleware harusnya sudah menyimpannya)
	uid, exists := c.Get("userID")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User tidak terautentikasi"})
		return
	}

	userID, ok := uid.(uint)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Invalid userID"})
		return
	}

	orders, err := services.GetOrdersByUserID(userID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Gagal ambil riwayat pesanan"})
		return
	}
	c.JSON(http.StatusOK, orders)
}
